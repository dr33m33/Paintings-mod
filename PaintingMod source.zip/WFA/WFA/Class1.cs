﻿using BepInEx;
using UnityEngine;
using UnityEngine.UI;
using System.IO;

namespace CustomPaintingMod
{
    [BepInPlugin("com.yourname.custompaintingmod", "Custom Painting Mod", "2.4.1")]
    public class Plugin : BaseUnityPlugin
    {
        private const string PaintingsFolderName = "CustomPaintings";
        private GameObject paintingQuad;
        private Canvas canvas;
        private RawImage paintingImage;
        private Text fallbackText;

        void Start()
        {
            CreatePaintingsFolder();
            CreatePaintingQuadWithUI();
            LoadAndApplyPainting();
        }

        private void CreatePaintingsFolder()
        {
            string folderPath = Path.Combine(Paths.PluginPath, PaintingsFolderName);
            if (!Directory.Exists(folderPath))
            {
                Directory.CreateDirectory(folderPath);
                Logger.LogInfo($"Created folder at {folderPath}. Add PNG files here.");
            }
        }

        private void CreatePaintingQuadWithUI()
        {
            paintingQuad = GameObject.CreatePrimitive(PrimitiveType.Quad);
            paintingQuad.transform.position = new Vector3(-66.7393f, 12.3f, -85.1139f);
            paintingQuad.transform.localScale = new Vector3(1, 1, 2);
            paintingQuad.transform.rotation = Quaternion.Euler(0.2052f, 340.1811f, 0);
            DestroyImmediate(paintingQuad.GetComponent<Collider>());

            GameObject canvasObject = new GameObject("PaintingCanvas");
            canvasObject.transform.SetParent(paintingQuad.transform);
            canvasObject.transform.localPosition = Vector3.zero;
            canvasObject.transform.localRotation = Quaternion.identity;

            canvas = canvasObject.AddComponent<Canvas>();
            canvas.renderMode = RenderMode.WorldSpace;
            canvasObject.AddComponent<CanvasScaler>();

            RectTransform rectTransform = canvas.GetComponent<RectTransform>();
            rectTransform.sizeDelta = new Vector2(1, 1);

            GameObject imageObject = new GameObject("PaintingImage");
            paintingImage = imageObject.AddComponent<RawImage>();
            paintingImage.transform.SetParent(canvas.transform);
            paintingImage.rectTransform.sizeDelta = new Vector2(1, 1);
            paintingImage.rectTransform.localPosition = Vector3.zero;
            paintingImage.color = Color.red;

            GameObject textObject = new GameObject("FallbackText");
            fallbackText = textObject.AddComponent<Text>();
            fallbackText.transform.SetParent(canvas.transform);
            fallbackText.rectTransform.sizeDelta = new Vector2(1, 0.5f);
            fallbackText.rectTransform.localPosition = Vector3.zero;
            fallbackText.alignment = TextAnchor.MiddleCenter;
            fallbackText.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
            fallbackText.fontSize = 30;
            fallbackText.color = Color.white;
            fallbackText.text = "No Image Found!";
        }

        private void LoadAndApplyPainting()
        {
            string folderPath = Path.Combine(Paths.PluginPath, PaintingsFolderName);
            string[] files = Directory.GetFiles(folderPath, "*.png");

            if (files.Length == 0)
            {
                Logger.LogError("No PNG files found in CustomPaintings folder.");
                return;
            }

            string filePath = files[0];

            try
            {
                byte[] imageData = File.ReadAllBytes(filePath);
                Texture2D texture = new Texture2D(2, 2);
                texture.LoadImage(imageData);

                paintingImage.texture = texture;
                paintingImage.color = Color.white;
                fallbackText.text = "";
                Logger.LogInfo($"Loaded painting: {texture.width}x{texture.height}");
            }
            catch (System.Exception ex)
            {
                Logger.LogError($"Error loading painting: {ex.Message}");
            }
        }

        void OnDestroy()
        {
            if (paintingQuad != null)
            {
                Destroy(paintingQuad);
            }
        }
    }
}
